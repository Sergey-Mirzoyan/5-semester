use data

declare @num integer = 5
declare @output integer

exec Factorial 5, @output output

print @output