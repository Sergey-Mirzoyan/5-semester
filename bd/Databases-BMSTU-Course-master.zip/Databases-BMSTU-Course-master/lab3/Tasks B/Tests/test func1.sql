use data

go

exec dbo.debug_message 'Test message'

go