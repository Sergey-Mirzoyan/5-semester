insert into companies (company, address, city, sector)
values 
    ('Google', 'Mountain View, CA', 'Palo Alto', 'IT')

go

insert into companies (company, address, city, sector)
values 
    ('Amazon', '5th Avenue, 5369', 'NYC', 'IT')

go