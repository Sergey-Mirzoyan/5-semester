create database users

go

use users

go