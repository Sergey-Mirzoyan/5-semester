alter table companies
add
	id_cmp int identity(1, 1) not null
