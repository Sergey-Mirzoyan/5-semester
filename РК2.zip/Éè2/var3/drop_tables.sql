DROP TABLE RK2.dbo.Students
DROP TABLE RK2.dbo.Themes
DROP TABLE RK2.dbo.Teachers