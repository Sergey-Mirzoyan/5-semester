--Task2: Queries--

--SELECT with searchable CASE--

--Инструкция UPDATE со скалярным подзапросом в предложении SET--
